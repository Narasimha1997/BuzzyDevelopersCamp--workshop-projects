package com.example.narasimha.googlesignin;

/**
 * Created by narasimha on 17/3/18.
 */

public class MessageSource{
    public String email;
    public String message;

    MessageSource(String email, String message){
        this.email = email;
        this.message = message;
    }
}